package com.max.feedbackserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ServiceFeedbackserverSample1Application {

	public static void main(String[] args) {
		SpringApplication.run(ServiceFeedbackserverSample1Application.class, args);
	}

}
